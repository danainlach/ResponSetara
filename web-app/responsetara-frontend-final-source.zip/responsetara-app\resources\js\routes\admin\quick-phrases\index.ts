import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::restore
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:98
 * @route '/admin/quick-phrases/{id}/restore'
 */
export const restore = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/admin/quick-phrases/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::restore
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:98
 * @route '/admin/quick-phrases/{id}/restore'
 */
restore.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return restore.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::restore
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:98
 * @route '/admin/quick-phrases/{id}/restore'
 */
restore.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\QuickPhraseController::restore
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:98
 * @route '/admin/quick-phrases/{id}/restore'
 */
    const restoreForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\QuickPhraseController::restore
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:98
 * @route '/admin/quick-phrases/{id}/restore'
 */
        restoreForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, options),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::index
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:21
 * @route '/admin/quick-phrases'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/quick-phrases',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::index
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:21
 * @route '/admin/quick-phrases'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::index
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:21
 * @route '/admin/quick-phrases'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::index
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:21
 * @route '/admin/quick-phrases'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\QuickPhraseController::index
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:21
 * @route '/admin/quick-phrases'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\QuickPhraseController::index
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:21
 * @route '/admin/quick-phrases'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\QuickPhraseController::index
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:21
 * @route '/admin/quick-phrases'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::store
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:53
 * @route '/admin/quick-phrases'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/quick-phrases',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::store
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:53
 * @route '/admin/quick-phrases'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::store
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:53
 * @route '/admin/quick-phrases'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\QuickPhraseController::store
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:53
 * @route '/admin/quick-phrases'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\QuickPhraseController::store
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:53
 * @route '/admin/quick-phrases'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::update
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:68
 * @route '/admin/quick-phrases/{quick_phrase}'
 */
export const update = (args: { quick_phrase: number | { id: number } } | [quick_phrase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/quick-phrases/{quick_phrase}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::update
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:68
 * @route '/admin/quick-phrases/{quick_phrase}'
 */
update.url = (args: { quick_phrase: number | { id: number } } | [quick_phrase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { quick_phrase: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { quick_phrase: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    quick_phrase: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        quick_phrase: typeof args.quick_phrase === 'object'
                ? args.quick_phrase.id
                : args.quick_phrase,
                }

    return update.definition.url
            .replace('{quick_phrase}', parsedArgs.quick_phrase.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::update
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:68
 * @route '/admin/quick-phrases/{quick_phrase}'
 */
update.put = (args: { quick_phrase: number | { id: number } } | [quick_phrase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::update
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:68
 * @route '/admin/quick-phrases/{quick_phrase}'
 */
update.patch = (args: { quick_phrase: number | { id: number } } | [quick_phrase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\QuickPhraseController::update
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:68
 * @route '/admin/quick-phrases/{quick_phrase}'
 */
    const updateForm = (args: { quick_phrase: number | { id: number } } | [quick_phrase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\QuickPhraseController::update
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:68
 * @route '/admin/quick-phrases/{quick_phrase}'
 */
        updateForm.put = (args: { quick_phrase: number | { id: number } } | [quick_phrase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\QuickPhraseController::update
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:68
 * @route '/admin/quick-phrases/{quick_phrase}'
 */
        updateForm.patch = (args: { quick_phrase: number | { id: number } } | [quick_phrase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::destroy
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:83
 * @route '/admin/quick-phrases/{quick_phrase}'
 */
export const destroy = (args: { quick_phrase: number | { id: number } } | [quick_phrase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/quick-phrases/{quick_phrase}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::destroy
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:83
 * @route '/admin/quick-phrases/{quick_phrase}'
 */
destroy.url = (args: { quick_phrase: number | { id: number } } | [quick_phrase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { quick_phrase: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { quick_phrase: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    quick_phrase: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        quick_phrase: typeof args.quick_phrase === 'object'
                ? args.quick_phrase.id
                : args.quick_phrase,
                }

    return destroy.definition.url
            .replace('{quick_phrase}', parsedArgs.quick_phrase.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QuickPhraseController::destroy
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:83
 * @route '/admin/quick-phrases/{quick_phrase}'
 */
destroy.delete = (args: { quick_phrase: number | { id: number } } | [quick_phrase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\QuickPhraseController::destroy
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:83
 * @route '/admin/quick-phrases/{quick_phrase}'
 */
    const destroyForm = (args: { quick_phrase: number | { id: number } } | [quick_phrase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\QuickPhraseController::destroy
 * @see app/Http/Controllers/Admin/QuickPhraseController.php:83
 * @route '/admin/quick-phrases/{quick_phrase}'
 */
        destroyForm.delete = (args: { quick_phrase: number | { id: number } } | [quick_phrase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const quickPhrases = {
    restore: Object.assign(restore, restore),
index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default quickPhrases