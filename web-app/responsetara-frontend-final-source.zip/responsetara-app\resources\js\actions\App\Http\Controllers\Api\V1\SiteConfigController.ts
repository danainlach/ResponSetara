import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\SiteConfigController::index
 * @see app/Http/Controllers/Api/V1/SiteConfigController.php:16
 * @route '/api/v1/config'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/config',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\SiteConfigController::index
 * @see app/Http/Controllers/Api/V1/SiteConfigController.php:16
 * @route '/api/v1/config'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\SiteConfigController::index
 * @see app/Http/Controllers/Api/V1/SiteConfigController.php:16
 * @route '/api/v1/config'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\SiteConfigController::index
 * @see app/Http/Controllers/Api/V1/SiteConfigController.php:16
 * @route '/api/v1/config'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\SiteConfigController::index
 * @see app/Http/Controllers/Api/V1/SiteConfigController.php:16
 * @route '/api/v1/config'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\SiteConfigController::index
 * @see app/Http/Controllers/Api/V1/SiteConfigController.php:16
 * @route '/api/v1/config'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\SiteConfigController::index
 * @see app/Http/Controllers/Api/V1/SiteConfigController.php:16
 * @route '/api/v1/config'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const SiteConfigController = { index }

export default SiteConfigController