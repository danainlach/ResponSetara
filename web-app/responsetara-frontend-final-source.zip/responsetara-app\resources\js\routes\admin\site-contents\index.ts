import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\SiteContentController::index
 * @see app/Http/Controllers/Admin/SiteContentController.php:18
 * @route '/admin/site-contents'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/site-contents',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SiteContentController::index
 * @see app/Http/Controllers/Admin/SiteContentController.php:18
 * @route '/admin/site-contents'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SiteContentController::index
 * @see app/Http/Controllers/Admin/SiteContentController.php:18
 * @route '/admin/site-contents'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\SiteContentController::index
 * @see app/Http/Controllers/Admin/SiteContentController.php:18
 * @route '/admin/site-contents'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\SiteContentController::index
 * @see app/Http/Controllers/Admin/SiteContentController.php:18
 * @route '/admin/site-contents'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\SiteContentController::index
 * @see app/Http/Controllers/Admin/SiteContentController.php:18
 * @route '/admin/site-contents'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\SiteContentController::index
 * @see app/Http/Controllers/Admin/SiteContentController.php:18
 * @route '/admin/site-contents'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\SiteContentController::store
 * @see app/Http/Controllers/Admin/SiteContentController.php:36
 * @route '/admin/site-contents'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/site-contents',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SiteContentController::store
 * @see app/Http/Controllers/Admin/SiteContentController.php:36
 * @route '/admin/site-contents'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SiteContentController::store
 * @see app/Http/Controllers/Admin/SiteContentController.php:36
 * @route '/admin/site-contents'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\SiteContentController::store
 * @see app/Http/Controllers/Admin/SiteContentController.php:36
 * @route '/admin/site-contents'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SiteContentController::store
 * @see app/Http/Controllers/Admin/SiteContentController.php:36
 * @route '/admin/site-contents'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\SiteContentController::update
 * @see app/Http/Controllers/Admin/SiteContentController.php:51
 * @route '/admin/site-contents/{site_content}'
 */
export const update = (args: { site_content: number | { id: number } } | [site_content: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/site-contents/{site_content}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\SiteContentController::update
 * @see app/Http/Controllers/Admin/SiteContentController.php:51
 * @route '/admin/site-contents/{site_content}'
 */
update.url = (args: { site_content: number | { id: number } } | [site_content: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site_content: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site_content: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site_content: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site_content: typeof args.site_content === 'object'
                ? args.site_content.id
                : args.site_content,
                }

    return update.definition.url
            .replace('{site_content}', parsedArgs.site_content.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SiteContentController::update
 * @see app/Http/Controllers/Admin/SiteContentController.php:51
 * @route '/admin/site-contents/{site_content}'
 */
update.put = (args: { site_content: number | { id: number } } | [site_content: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\SiteContentController::update
 * @see app/Http/Controllers/Admin/SiteContentController.php:51
 * @route '/admin/site-contents/{site_content}'
 */
update.patch = (args: { site_content: number | { id: number } } | [site_content: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\SiteContentController::update
 * @see app/Http/Controllers/Admin/SiteContentController.php:51
 * @route '/admin/site-contents/{site_content}'
 */
    const updateForm = (args: { site_content: number | { id: number } } | [site_content: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SiteContentController::update
 * @see app/Http/Controllers/Admin/SiteContentController.php:51
 * @route '/admin/site-contents/{site_content}'
 */
        updateForm.put = (args: { site_content: number | { id: number } } | [site_content: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\SiteContentController::update
 * @see app/Http/Controllers/Admin/SiteContentController.php:51
 * @route '/admin/site-contents/{site_content}'
 */
        updateForm.patch = (args: { site_content: number | { id: number } } | [site_content: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\SiteContentController::destroy
 * @see app/Http/Controllers/Admin/SiteContentController.php:66
 * @route '/admin/site-contents/{site_content}'
 */
export const destroy = (args: { site_content: number | { id: number } } | [site_content: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/site-contents/{site_content}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\SiteContentController::destroy
 * @see app/Http/Controllers/Admin/SiteContentController.php:66
 * @route '/admin/site-contents/{site_content}'
 */
destroy.url = (args: { site_content: number | { id: number } } | [site_content: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site_content: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site_content: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site_content: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site_content: typeof args.site_content === 'object'
                ? args.site_content.id
                : args.site_content,
                }

    return destroy.definition.url
            .replace('{site_content}', parsedArgs.site_content.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SiteContentController::destroy
 * @see app/Http/Controllers/Admin/SiteContentController.php:66
 * @route '/admin/site-contents/{site_content}'
 */
destroy.delete = (args: { site_content: number | { id: number } } | [site_content: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\SiteContentController::destroy
 * @see app/Http/Controllers/Admin/SiteContentController.php:66
 * @route '/admin/site-contents/{site_content}'
 */
    const destroyForm = (args: { site_content: number | { id: number } } | [site_content: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SiteContentController::destroy
 * @see app/Http/Controllers/Admin/SiteContentController.php:66
 * @route '/admin/site-contents/{site_content}'
 */
        destroyForm.delete = (args: { site_content: number | { id: number } } | [site_content: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const siteContents = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default siteContents