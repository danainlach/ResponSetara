import DashboardController from './DashboardController'
import CategoryController from './CategoryController'
import ConditionController from './ConditionController'
import AssistanceTypeController from './AssistanceTypeController'
import QuickPhraseController from './QuickPhraseController'
import HelperGuideController from './HelperGuideController'
import EmergencyContactController from './EmergencyContactController'
import SiteContentController from './SiteContentController'
import AiPromptController from './AiPromptController'
import StatisticController from './StatisticController'
import ActivityLogController from './ActivityLogController'
const Admin = {
    DashboardController: Object.assign(DashboardController, DashboardController),
CategoryController: Object.assign(CategoryController, CategoryController),
ConditionController: Object.assign(ConditionController, ConditionController),
AssistanceTypeController: Object.assign(AssistanceTypeController, AssistanceTypeController),
QuickPhraseController: Object.assign(QuickPhraseController, QuickPhraseController),
HelperGuideController: Object.assign(HelperGuideController, HelperGuideController),
EmergencyContactController: Object.assign(EmergencyContactController, EmergencyContactController),
SiteContentController: Object.assign(SiteContentController, SiteContentController),
AiPromptController: Object.assign(AiPromptController, AiPromptController),
StatisticController: Object.assign(StatisticController, StatisticController),
ActivityLogController: Object.assign(ActivityLogController, ActivityLogController),
}

export default Admin