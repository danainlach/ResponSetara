import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\NonverbalController::index
 * @see app/Http/Controllers/NonverbalController.php:23
 * @route '/tidak-dapat-berbicara'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/tidak-dapat-berbicara',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NonverbalController::index
 * @see app/Http/Controllers/NonverbalController.php:23
 * @route '/tidak-dapat-berbicara'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NonverbalController::index
 * @see app/Http/Controllers/NonverbalController.php:23
 * @route '/tidak-dapat-berbicara'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\NonverbalController::index
 * @see app/Http/Controllers/NonverbalController.php:23
 * @route '/tidak-dapat-berbicara'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\NonverbalController::index
 * @see app/Http/Controllers/NonverbalController.php:23
 * @route '/tidak-dapat-berbicara'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\NonverbalController::index
 * @see app/Http/Controllers/NonverbalController.php:23
 * @route '/tidak-dapat-berbicara'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\NonverbalController::index
 * @see app/Http/Controllers/NonverbalController.php:23
 * @route '/tidak-dapat-berbicara'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
 * @see routes/web.php:25
 * @route '/nonverbal'
 */
export const alias = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: alias.url(options),
    method: 'get',
})

alias.definition = {
    methods: ["get","head"],
    url: '/nonverbal',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:25
 * @route '/nonverbal'
 */
alias.url = (options?: RouteQueryOptions) => {
    return alias.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:25
 * @route '/nonverbal'
 */
alias.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: alias.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:25
 * @route '/nonverbal'
 */
alias.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: alias.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:25
 * @route '/nonverbal'
 */
    const aliasForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: alias.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:25
 * @route '/nonverbal'
 */
        aliasForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: alias.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:25
 * @route '/nonverbal'
 */
        aliasForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: alias.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    alias.form = aliasForm
const nonverbal = {
    index: Object.assign(index, index),
alias: Object.assign(alias, alias),
}

export default nonverbal