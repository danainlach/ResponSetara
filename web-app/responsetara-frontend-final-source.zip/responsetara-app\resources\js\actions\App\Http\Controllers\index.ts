import Api from './Api'
import HomeController from './HomeController'
import AssistanceController from './AssistanceController'
import NonverbalController from './NonverbalController'
import DeafController from './DeafController'
import Admin from './Admin'
import Settings from './Settings'
const Controllers = {
    Api: Object.assign(Api, Api),
HomeController: Object.assign(HomeController, HomeController),
AssistanceController: Object.assign(AssistanceController, AssistanceController),
NonverbalController: Object.assign(NonverbalController, NonverbalController),
DeafController: Object.assign(DeafController, DeafController),
Admin: Object.assign(Admin, Admin),
Settings: Object.assign(Settings, Settings),
}

export default Controllers