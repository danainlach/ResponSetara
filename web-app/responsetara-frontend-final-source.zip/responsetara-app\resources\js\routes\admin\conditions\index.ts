import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ConditionController::restore
 * @see app/Http/Controllers/Admin/ConditionController.php:90
 * @route '/admin/conditions/{id}/restore'
 */
export const restore = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/admin/conditions/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ConditionController::restore
 * @see app/Http/Controllers/Admin/ConditionController.php:90
 * @route '/admin/conditions/{id}/restore'
 */
restore.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return restore.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ConditionController::restore
 * @see app/Http/Controllers/Admin/ConditionController.php:90
 * @route '/admin/conditions/{id}/restore'
 */
restore.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ConditionController::restore
 * @see app/Http/Controllers/Admin/ConditionController.php:90
 * @route '/admin/conditions/{id}/restore'
 */
    const restoreForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ConditionController::restore
 * @see app/Http/Controllers/Admin/ConditionController.php:90
 * @route '/admin/conditions/{id}/restore'
 */
        restoreForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, options),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\Admin\ConditionController::index
 * @see app/Http/Controllers/Admin/ConditionController.php:19
 * @route '/admin/conditions'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/conditions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ConditionController::index
 * @see app/Http/Controllers/Admin/ConditionController.php:19
 * @route '/admin/conditions'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ConditionController::index
 * @see app/Http/Controllers/Admin/ConditionController.php:19
 * @route '/admin/conditions'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ConditionController::index
 * @see app/Http/Controllers/Admin/ConditionController.php:19
 * @route '/admin/conditions'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ConditionController::index
 * @see app/Http/Controllers/Admin/ConditionController.php:19
 * @route '/admin/conditions'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ConditionController::index
 * @see app/Http/Controllers/Admin/ConditionController.php:19
 * @route '/admin/conditions'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ConditionController::index
 * @see app/Http/Controllers/Admin/ConditionController.php:19
 * @route '/admin/conditions'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\ConditionController::store
 * @see app/Http/Controllers/Admin/ConditionController.php:45
 * @route '/admin/conditions'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/conditions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ConditionController::store
 * @see app/Http/Controllers/Admin/ConditionController.php:45
 * @route '/admin/conditions'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ConditionController::store
 * @see app/Http/Controllers/Admin/ConditionController.php:45
 * @route '/admin/conditions'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ConditionController::store
 * @see app/Http/Controllers/Admin/ConditionController.php:45
 * @route '/admin/conditions'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ConditionController::store
 * @see app/Http/Controllers/Admin/ConditionController.php:45
 * @route '/admin/conditions'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\ConditionController::update
 * @see app/Http/Controllers/Admin/ConditionController.php:60
 * @route '/admin/conditions/{condition}'
 */
export const update = (args: { condition: number | { id: number } } | [condition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/conditions/{condition}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\ConditionController::update
 * @see app/Http/Controllers/Admin/ConditionController.php:60
 * @route '/admin/conditions/{condition}'
 */
update.url = (args: { condition: number | { id: number } } | [condition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { condition: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { condition: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    condition: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        condition: typeof args.condition === 'object'
                ? args.condition.id
                : args.condition,
                }

    return update.definition.url
            .replace('{condition}', parsedArgs.condition.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ConditionController::update
 * @see app/Http/Controllers/Admin/ConditionController.php:60
 * @route '/admin/conditions/{condition}'
 */
update.put = (args: { condition: number | { id: number } } | [condition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\ConditionController::update
 * @see app/Http/Controllers/Admin/ConditionController.php:60
 * @route '/admin/conditions/{condition}'
 */
update.patch = (args: { condition: number | { id: number } } | [condition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\ConditionController::update
 * @see app/Http/Controllers/Admin/ConditionController.php:60
 * @route '/admin/conditions/{condition}'
 */
    const updateForm = (args: { condition: number | { id: number } } | [condition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ConditionController::update
 * @see app/Http/Controllers/Admin/ConditionController.php:60
 * @route '/admin/conditions/{condition}'
 */
        updateForm.put = (args: { condition: number | { id: number } } | [condition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\ConditionController::update
 * @see app/Http/Controllers/Admin/ConditionController.php:60
 * @route '/admin/conditions/{condition}'
 */
        updateForm.patch = (args: { condition: number | { id: number } } | [condition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\ConditionController::destroy
 * @see app/Http/Controllers/Admin/ConditionController.php:75
 * @route '/admin/conditions/{condition}'
 */
export const destroy = (args: { condition: number | { id: number } } | [condition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/conditions/{condition}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\ConditionController::destroy
 * @see app/Http/Controllers/Admin/ConditionController.php:75
 * @route '/admin/conditions/{condition}'
 */
destroy.url = (args: { condition: number | { id: number } } | [condition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { condition: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { condition: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    condition: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        condition: typeof args.condition === 'object'
                ? args.condition.id
                : args.condition,
                }

    return destroy.definition.url
            .replace('{condition}', parsedArgs.condition.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ConditionController::destroy
 * @see app/Http/Controllers/Admin/ConditionController.php:75
 * @route '/admin/conditions/{condition}'
 */
destroy.delete = (args: { condition: number | { id: number } } | [condition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\ConditionController::destroy
 * @see app/Http/Controllers/Admin/ConditionController.php:75
 * @route '/admin/conditions/{condition}'
 */
    const destroyForm = (args: { condition: number | { id: number } } | [condition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ConditionController::destroy
 * @see app/Http/Controllers/Admin/ConditionController.php:75
 * @route '/admin/conditions/{condition}'
 */
        destroyForm.delete = (args: { condition: number | { id: number } } | [condition: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const conditions = {
    restore: Object.assign(restore, restore),
index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default conditions