import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AiPromptController::restore
 * @see app/Http/Controllers/Admin/AiPromptController.php:102
 * @route '/admin/ai-prompts/{id}/restore'
 */
export const restore = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/admin/ai-prompts/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AiPromptController::restore
 * @see app/Http/Controllers/Admin/AiPromptController.php:102
 * @route '/admin/ai-prompts/{id}/restore'
 */
restore.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return restore.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AiPromptController::restore
 * @see app/Http/Controllers/Admin/AiPromptController.php:102
 * @route '/admin/ai-prompts/{id}/restore'
 */
restore.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AiPromptController::restore
 * @see app/Http/Controllers/Admin/AiPromptController.php:102
 * @route '/admin/ai-prompts/{id}/restore'
 */
    const restoreForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AiPromptController::restore
 * @see app/Http/Controllers/Admin/AiPromptController.php:102
 * @route '/admin/ai-prompts/{id}/restore'
 */
        restoreForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, options),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\Admin\AiPromptController::index
 * @see app/Http/Controllers/Admin/AiPromptController.php:19
 * @route '/admin/ai-prompts'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/ai-prompts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AiPromptController::index
 * @see app/Http/Controllers/Admin/AiPromptController.php:19
 * @route '/admin/ai-prompts'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AiPromptController::index
 * @see app/Http/Controllers/Admin/AiPromptController.php:19
 * @route '/admin/ai-prompts'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AiPromptController::index
 * @see app/Http/Controllers/Admin/AiPromptController.php:19
 * @route '/admin/ai-prompts'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AiPromptController::index
 * @see app/Http/Controllers/Admin/AiPromptController.php:19
 * @route '/admin/ai-prompts'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AiPromptController::index
 * @see app/Http/Controllers/Admin/AiPromptController.php:19
 * @route '/admin/ai-prompts'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AiPromptController::index
 * @see app/Http/Controllers/Admin/AiPromptController.php:19
 * @route '/admin/ai-prompts'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AiPromptController::store
 * @see app/Http/Controllers/Admin/AiPromptController.php:41
 * @route '/admin/ai-prompts'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/ai-prompts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AiPromptController::store
 * @see app/Http/Controllers/Admin/AiPromptController.php:41
 * @route '/admin/ai-prompts'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AiPromptController::store
 * @see app/Http/Controllers/Admin/AiPromptController.php:41
 * @route '/admin/ai-prompts'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AiPromptController::store
 * @see app/Http/Controllers/Admin/AiPromptController.php:41
 * @route '/admin/ai-prompts'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AiPromptController::store
 * @see app/Http/Controllers/Admin/AiPromptController.php:41
 * @route '/admin/ai-prompts'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AiPromptController::update
 * @see app/Http/Controllers/Admin/AiPromptController.php:64
 * @route '/admin/ai-prompts/{ai_prompt}'
 */
export const update = (args: { ai_prompt: number | { id: number } } | [ai_prompt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/ai-prompts/{ai_prompt}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\AiPromptController::update
 * @see app/Http/Controllers/Admin/AiPromptController.php:64
 * @route '/admin/ai-prompts/{ai_prompt}'
 */
update.url = (args: { ai_prompt: number | { id: number } } | [ai_prompt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ai_prompt: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ai_prompt: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ai_prompt: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ai_prompt: typeof args.ai_prompt === 'object'
                ? args.ai_prompt.id
                : args.ai_prompt,
                }

    return update.definition.url
            .replace('{ai_prompt}', parsedArgs.ai_prompt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AiPromptController::update
 * @see app/Http/Controllers/Admin/AiPromptController.php:64
 * @route '/admin/ai-prompts/{ai_prompt}'
 */
update.put = (args: { ai_prompt: number | { id: number } } | [ai_prompt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\AiPromptController::update
 * @see app/Http/Controllers/Admin/AiPromptController.php:64
 * @route '/admin/ai-prompts/{ai_prompt}'
 */
update.patch = (args: { ai_prompt: number | { id: number } } | [ai_prompt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AiPromptController::update
 * @see app/Http/Controllers/Admin/AiPromptController.php:64
 * @route '/admin/ai-prompts/{ai_prompt}'
 */
    const updateForm = (args: { ai_prompt: number | { id: number } } | [ai_prompt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AiPromptController::update
 * @see app/Http/Controllers/Admin/AiPromptController.php:64
 * @route '/admin/ai-prompts/{ai_prompt}'
 */
        updateForm.put = (args: { ai_prompt: number | { id: number } } | [ai_prompt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\AiPromptController::update
 * @see app/Http/Controllers/Admin/AiPromptController.php:64
 * @route '/admin/ai-prompts/{ai_prompt}'
 */
        updateForm.patch = (args: { ai_prompt: number | { id: number } } | [ai_prompt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AiPromptController::destroy
 * @see app/Http/Controllers/Admin/AiPromptController.php:87
 * @route '/admin/ai-prompts/{ai_prompt}'
 */
export const destroy = (args: { ai_prompt: number | { id: number } } | [ai_prompt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/ai-prompts/{ai_prompt}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AiPromptController::destroy
 * @see app/Http/Controllers/Admin/AiPromptController.php:87
 * @route '/admin/ai-prompts/{ai_prompt}'
 */
destroy.url = (args: { ai_prompt: number | { id: number } } | [ai_prompt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ai_prompt: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ai_prompt: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ai_prompt: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ai_prompt: typeof args.ai_prompt === 'object'
                ? args.ai_prompt.id
                : args.ai_prompt,
                }

    return destroy.definition.url
            .replace('{ai_prompt}', parsedArgs.ai_prompt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AiPromptController::destroy
 * @see app/Http/Controllers/Admin/AiPromptController.php:87
 * @route '/admin/ai-prompts/{ai_prompt}'
 */
destroy.delete = (args: { ai_prompt: number | { id: number } } | [ai_prompt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AiPromptController::destroy
 * @see app/Http/Controllers/Admin/AiPromptController.php:87
 * @route '/admin/ai-prompts/{ai_prompt}'
 */
    const destroyForm = (args: { ai_prompt: number | { id: number } } | [ai_prompt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AiPromptController::destroy
 * @see app/Http/Controllers/Admin/AiPromptController.php:87
 * @route '/admin/ai-prompts/{ai_prompt}'
 */
        destroyForm.delete = (args: { ai_prompt: number | { id: number } } | [ai_prompt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const aiPrompts = {
    restore: Object.assign(restore, restore),
index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default aiPrompts