import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\NonverbalController::index
 * @see app/Http/Controllers/NonverbalController.php:23
 * @route '/tidak-dapat-berbicara'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/tidak-dapat-berbicara',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NonverbalController::index
 * @see app/Http/Controllers/NonverbalController.php:23
 * @route '/tidak-dapat-berbicara'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NonverbalController::index
 * @see app/Http/Controllers/NonverbalController.php:23
 * @route '/tidak-dapat-berbicara'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\NonverbalController::index
 * @see app/Http/Controllers/NonverbalController.php:23
 * @route '/tidak-dapat-berbicara'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\NonverbalController::index
 * @see app/Http/Controllers/NonverbalController.php:23
 * @route '/tidak-dapat-berbicara'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\NonverbalController::index
 * @see app/Http/Controllers/NonverbalController.php:23
 * @route '/tidak-dapat-berbicara'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\NonverbalController::index
 * @see app/Http/Controllers/NonverbalController.php:23
 * @route '/tidak-dapat-berbicara'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const NonverbalController = { index }

export default NonverbalController