import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/bantuan-darurat'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/bantuan-darurat',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/bantuan-darurat'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/bantuan-darurat'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/bantuan-darurat'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/bantuan-darurat'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/bantuan-darurat'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/bantuan-darurat'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AssistanceController::en
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/assistance'
 */
export const en = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: en.url(options),
    method: 'get',
})

en.definition = {
    methods: ["get","head"],
    url: '/assistance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AssistanceController::en
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/assistance'
 */
en.url = (options?: RouteQueryOptions) => {
    return en.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssistanceController::en
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/assistance'
 */
en.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: en.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AssistanceController::en
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/assistance'
 */
en.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: en.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AssistanceController::en
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/assistance'
 */
    const enForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: en.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AssistanceController::en
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/assistance'
 */
        enForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: en.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AssistanceController::en
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/assistance'
 */
        enForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: en.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    en.form = enForm
const assistance = {
    index: Object.assign(index, index),
en: Object.assign(en, en),
}

export default assistance