import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::restore
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:85
 * @route '/admin/emergency-contacts/{id}/restore'
 */
export const restore = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/admin/emergency-contacts/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::restore
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:85
 * @route '/admin/emergency-contacts/{id}/restore'
 */
restore.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return restore.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::restore
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:85
 * @route '/admin/emergency-contacts/{id}/restore'
 */
restore.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\EmergencyContactController::restore
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:85
 * @route '/admin/emergency-contacts/{id}/restore'
 */
    const restoreForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\EmergencyContactController::restore
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:85
 * @route '/admin/emergency-contacts/{id}/restore'
 */
        restoreForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, options),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::index
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:18
 * @route '/admin/emergency-contacts'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/emergency-contacts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::index
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:18
 * @route '/admin/emergency-contacts'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::index
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:18
 * @route '/admin/emergency-contacts'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::index
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:18
 * @route '/admin/emergency-contacts'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\EmergencyContactController::index
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:18
 * @route '/admin/emergency-contacts'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\EmergencyContactController::index
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:18
 * @route '/admin/emergency-contacts'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\EmergencyContactController::index
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:18
 * @route '/admin/emergency-contacts'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::store
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:40
 * @route '/admin/emergency-contacts'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/emergency-contacts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::store
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:40
 * @route '/admin/emergency-contacts'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::store
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:40
 * @route '/admin/emergency-contacts'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\EmergencyContactController::store
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:40
 * @route '/admin/emergency-contacts'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\EmergencyContactController::store
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:40
 * @route '/admin/emergency-contacts'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::update
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:55
 * @route '/admin/emergency-contacts/{emergency_contact}'
 */
export const update = (args: { emergency_contact: number | { id: number } } | [emergency_contact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/emergency-contacts/{emergency_contact}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::update
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:55
 * @route '/admin/emergency-contacts/{emergency_contact}'
 */
update.url = (args: { emergency_contact: number | { id: number } } | [emergency_contact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { emergency_contact: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { emergency_contact: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    emergency_contact: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        emergency_contact: typeof args.emergency_contact === 'object'
                ? args.emergency_contact.id
                : args.emergency_contact,
                }

    return update.definition.url
            .replace('{emergency_contact}', parsedArgs.emergency_contact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::update
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:55
 * @route '/admin/emergency-contacts/{emergency_contact}'
 */
update.put = (args: { emergency_contact: number | { id: number } } | [emergency_contact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::update
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:55
 * @route '/admin/emergency-contacts/{emergency_contact}'
 */
update.patch = (args: { emergency_contact: number | { id: number } } | [emergency_contact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\EmergencyContactController::update
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:55
 * @route '/admin/emergency-contacts/{emergency_contact}'
 */
    const updateForm = (args: { emergency_contact: number | { id: number } } | [emergency_contact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\EmergencyContactController::update
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:55
 * @route '/admin/emergency-contacts/{emergency_contact}'
 */
        updateForm.put = (args: { emergency_contact: number | { id: number } } | [emergency_contact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\EmergencyContactController::update
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:55
 * @route '/admin/emergency-contacts/{emergency_contact}'
 */
        updateForm.patch = (args: { emergency_contact: number | { id: number } } | [emergency_contact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::destroy
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:70
 * @route '/admin/emergency-contacts/{emergency_contact}'
 */
export const destroy = (args: { emergency_contact: number | { id: number } } | [emergency_contact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/emergency-contacts/{emergency_contact}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::destroy
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:70
 * @route '/admin/emergency-contacts/{emergency_contact}'
 */
destroy.url = (args: { emergency_contact: number | { id: number } } | [emergency_contact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { emergency_contact: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { emergency_contact: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    emergency_contact: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        emergency_contact: typeof args.emergency_contact === 'object'
                ? args.emergency_contact.id
                : args.emergency_contact,
                }

    return destroy.definition.url
            .replace('{emergency_contact}', parsedArgs.emergency_contact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\EmergencyContactController::destroy
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:70
 * @route '/admin/emergency-contacts/{emergency_contact}'
 */
destroy.delete = (args: { emergency_contact: number | { id: number } } | [emergency_contact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\EmergencyContactController::destroy
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:70
 * @route '/admin/emergency-contacts/{emergency_contact}'
 */
    const destroyForm = (args: { emergency_contact: number | { id: number } } | [emergency_contact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\EmergencyContactController::destroy
 * @see app/Http/Controllers/Admin/EmergencyContactController.php:70
 * @route '/admin/emergency-contacts/{emergency_contact}'
 */
        destroyForm.delete = (args: { emergency_contact: number | { id: number } } | [emergency_contact: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const emergencyContacts = {
    restore: Object.assign(restore, restore),
index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default emergencyContacts