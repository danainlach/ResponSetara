import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\ComposeEmergencyMessageController::__invoke
 * @see app/Http/Controllers/Api/V1/ComposeEmergencyMessageController.php:19
 * @route '/api/v1/compose-message'
 */
const ComposeEmergencyMessageController = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ComposeEmergencyMessageController.url(options),
    method: 'post',
})

ComposeEmergencyMessageController.definition = {
    methods: ["post"],
    url: '/api/v1/compose-message',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\ComposeEmergencyMessageController::__invoke
 * @see app/Http/Controllers/Api/V1/ComposeEmergencyMessageController.php:19
 * @route '/api/v1/compose-message'
 */
ComposeEmergencyMessageController.url = (options?: RouteQueryOptions) => {
    return ComposeEmergencyMessageController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\ComposeEmergencyMessageController::__invoke
 * @see app/Http/Controllers/Api/V1/ComposeEmergencyMessageController.php:19
 * @route '/api/v1/compose-message'
 */
ComposeEmergencyMessageController.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ComposeEmergencyMessageController.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\ComposeEmergencyMessageController::__invoke
 * @see app/Http/Controllers/Api/V1/ComposeEmergencyMessageController.php:19
 * @route '/api/v1/compose-message'
 */
    const ComposeEmergencyMessageControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: ComposeEmergencyMessageController.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\ComposeEmergencyMessageController::__invoke
 * @see app/Http/Controllers/Api/V1/ComposeEmergencyMessageController.php:19
 * @route '/api/v1/compose-message'
 */
        ComposeEmergencyMessageControllerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: ComposeEmergencyMessageController.url(options),
            method: 'post',
        })
    
    ComposeEmergencyMessageController.form = ComposeEmergencyMessageControllerForm
export default ComposeEmergencyMessageController