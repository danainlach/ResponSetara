import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\QuickPhraseController::index
 * @see app/Http/Controllers/Api/V1/QuickPhraseController.php:17
 * @route '/api/v1/quick-phrases'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/quick-phrases',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\QuickPhraseController::index
 * @see app/Http/Controllers/Api/V1/QuickPhraseController.php:17
 * @route '/api/v1/quick-phrases'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\QuickPhraseController::index
 * @see app/Http/Controllers/Api/V1/QuickPhraseController.php:17
 * @route '/api/v1/quick-phrases'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\QuickPhraseController::index
 * @see app/Http/Controllers/Api/V1/QuickPhraseController.php:17
 * @route '/api/v1/quick-phrases'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\QuickPhraseController::index
 * @see app/Http/Controllers/Api/V1/QuickPhraseController.php:17
 * @route '/api/v1/quick-phrases'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\QuickPhraseController::index
 * @see app/Http/Controllers/Api/V1/QuickPhraseController.php:17
 * @route '/api/v1/quick-phrases'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\QuickPhraseController::index
 * @see app/Http/Controllers/Api/V1/QuickPhraseController.php:17
 * @route '/api/v1/quick-phrases'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const QuickPhraseController = { index }

export default QuickPhraseController