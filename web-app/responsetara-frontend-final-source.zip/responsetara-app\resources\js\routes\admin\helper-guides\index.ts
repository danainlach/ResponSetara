import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\HelperGuideController::restore
 * @see app/Http/Controllers/Admin/HelperGuideController.php:91
 * @route '/admin/helper-guides/{id}/restore'
 */
export const restore = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/admin/helper-guides/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\HelperGuideController::restore
 * @see app/Http/Controllers/Admin/HelperGuideController.php:91
 * @route '/admin/helper-guides/{id}/restore'
 */
restore.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return restore.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HelperGuideController::restore
 * @see app/Http/Controllers/Admin/HelperGuideController.php:91
 * @route '/admin/helper-guides/{id}/restore'
 */
restore.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\HelperGuideController::restore
 * @see app/Http/Controllers/Admin/HelperGuideController.php:91
 * @route '/admin/helper-guides/{id}/restore'
 */
    const restoreForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\HelperGuideController::restore
 * @see app/Http/Controllers/Admin/HelperGuideController.php:91
 * @route '/admin/helper-guides/{id}/restore'
 */
        restoreForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, options),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\Admin\HelperGuideController::index
 * @see app/Http/Controllers/Admin/HelperGuideController.php:19
 * @route '/admin/helper-guides'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/helper-guides',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\HelperGuideController::index
 * @see app/Http/Controllers/Admin/HelperGuideController.php:19
 * @route '/admin/helper-guides'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HelperGuideController::index
 * @see app/Http/Controllers/Admin/HelperGuideController.php:19
 * @route '/admin/helper-guides'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\HelperGuideController::index
 * @see app/Http/Controllers/Admin/HelperGuideController.php:19
 * @route '/admin/helper-guides'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\HelperGuideController::index
 * @see app/Http/Controllers/Admin/HelperGuideController.php:19
 * @route '/admin/helper-guides'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\HelperGuideController::index
 * @see app/Http/Controllers/Admin/HelperGuideController.php:19
 * @route '/admin/helper-guides'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\HelperGuideController::index
 * @see app/Http/Controllers/Admin/HelperGuideController.php:19
 * @route '/admin/helper-guides'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\HelperGuideController::store
 * @see app/Http/Controllers/Admin/HelperGuideController.php:46
 * @route '/admin/helper-guides'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/helper-guides',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\HelperGuideController::store
 * @see app/Http/Controllers/Admin/HelperGuideController.php:46
 * @route '/admin/helper-guides'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HelperGuideController::store
 * @see app/Http/Controllers/Admin/HelperGuideController.php:46
 * @route '/admin/helper-guides'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\HelperGuideController::store
 * @see app/Http/Controllers/Admin/HelperGuideController.php:46
 * @route '/admin/helper-guides'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\HelperGuideController::store
 * @see app/Http/Controllers/Admin/HelperGuideController.php:46
 * @route '/admin/helper-guides'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\HelperGuideController::update
 * @see app/Http/Controllers/Admin/HelperGuideController.php:61
 * @route '/admin/helper-guides/{helper_guide}'
 */
export const update = (args: { helper_guide: number | { id: number } } | [helper_guide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/helper-guides/{helper_guide}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\HelperGuideController::update
 * @see app/Http/Controllers/Admin/HelperGuideController.php:61
 * @route '/admin/helper-guides/{helper_guide}'
 */
update.url = (args: { helper_guide: number | { id: number } } | [helper_guide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { helper_guide: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { helper_guide: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    helper_guide: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        helper_guide: typeof args.helper_guide === 'object'
                ? args.helper_guide.id
                : args.helper_guide,
                }

    return update.definition.url
            .replace('{helper_guide}', parsedArgs.helper_guide.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HelperGuideController::update
 * @see app/Http/Controllers/Admin/HelperGuideController.php:61
 * @route '/admin/helper-guides/{helper_guide}'
 */
update.put = (args: { helper_guide: number | { id: number } } | [helper_guide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\HelperGuideController::update
 * @see app/Http/Controllers/Admin/HelperGuideController.php:61
 * @route '/admin/helper-guides/{helper_guide}'
 */
update.patch = (args: { helper_guide: number | { id: number } } | [helper_guide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\HelperGuideController::update
 * @see app/Http/Controllers/Admin/HelperGuideController.php:61
 * @route '/admin/helper-guides/{helper_guide}'
 */
    const updateForm = (args: { helper_guide: number | { id: number } } | [helper_guide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\HelperGuideController::update
 * @see app/Http/Controllers/Admin/HelperGuideController.php:61
 * @route '/admin/helper-guides/{helper_guide}'
 */
        updateForm.put = (args: { helper_guide: number | { id: number } } | [helper_guide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\HelperGuideController::update
 * @see app/Http/Controllers/Admin/HelperGuideController.php:61
 * @route '/admin/helper-guides/{helper_guide}'
 */
        updateForm.patch = (args: { helper_guide: number | { id: number } } | [helper_guide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\HelperGuideController::destroy
 * @see app/Http/Controllers/Admin/HelperGuideController.php:76
 * @route '/admin/helper-guides/{helper_guide}'
 */
export const destroy = (args: { helper_guide: number | { id: number } } | [helper_guide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/helper-guides/{helper_guide}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\HelperGuideController::destroy
 * @see app/Http/Controllers/Admin/HelperGuideController.php:76
 * @route '/admin/helper-guides/{helper_guide}'
 */
destroy.url = (args: { helper_guide: number | { id: number } } | [helper_guide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { helper_guide: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { helper_guide: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    helper_guide: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        helper_guide: typeof args.helper_guide === 'object'
                ? args.helper_guide.id
                : args.helper_guide,
                }

    return destroy.definition.url
            .replace('{helper_guide}', parsedArgs.helper_guide.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HelperGuideController::destroy
 * @see app/Http/Controllers/Admin/HelperGuideController.php:76
 * @route '/admin/helper-guides/{helper_guide}'
 */
destroy.delete = (args: { helper_guide: number | { id: number } } | [helper_guide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\HelperGuideController::destroy
 * @see app/Http/Controllers/Admin/HelperGuideController.php:76
 * @route '/admin/helper-guides/{helper_guide}'
 */
    const destroyForm = (args: { helper_guide: number | { id: number } } | [helper_guide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\HelperGuideController::destroy
 * @see app/Http/Controllers/Admin/HelperGuideController.php:76
 * @route '/admin/helper-guides/{helper_guide}'
 */
        destroyForm.delete = (args: { helper_guide: number | { id: number } } | [helper_guide: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const helperGuides = {
    restore: Object.assign(restore, restore),
index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default helperGuides