import SiteConfigController from './SiteConfigController'
import EmergencyCategoryController from './EmergencyCategoryController'
import EmergencyConditionController from './EmergencyConditionController'
import AssistanceTypeController from './AssistanceTypeController'
import QuickPhraseController from './QuickPhraseController'
import HelperGuideController from './HelperGuideController'
import EmergencyContactController from './EmergencyContactController'
import ComposeEmergencyMessageController from './ComposeEmergencyMessageController'
const V1 = {
    SiteConfigController: Object.assign(SiteConfigController, SiteConfigController),
EmergencyCategoryController: Object.assign(EmergencyCategoryController, EmergencyCategoryController),
EmergencyConditionController: Object.assign(EmergencyConditionController, EmergencyConditionController),
AssistanceTypeController: Object.assign(AssistanceTypeController, AssistanceTypeController),
QuickPhraseController: Object.assign(QuickPhraseController, QuickPhraseController),
HelperGuideController: Object.assign(HelperGuideController, HelperGuideController),
EmergencyContactController: Object.assign(EmergencyContactController, EmergencyContactController),
ComposeEmergencyMessageController: Object.assign(ComposeEmergencyMessageController, ComposeEmergencyMessageController),
}

export default V1