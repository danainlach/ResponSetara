import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\EmergencyContactController::index
 * @see app/Http/Controllers/Api/V1/EmergencyContactController.php:17
 * @route '/api/v1/emergency-contacts'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/emergency-contacts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\EmergencyContactController::index
 * @see app/Http/Controllers/Api/V1/EmergencyContactController.php:17
 * @route '/api/v1/emergency-contacts'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\EmergencyContactController::index
 * @see app/Http/Controllers/Api/V1/EmergencyContactController.php:17
 * @route '/api/v1/emergency-contacts'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\EmergencyContactController::index
 * @see app/Http/Controllers/Api/V1/EmergencyContactController.php:17
 * @route '/api/v1/emergency-contacts'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\EmergencyContactController::index
 * @see app/Http/Controllers/Api/V1/EmergencyContactController.php:17
 * @route '/api/v1/emergency-contacts'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\EmergencyContactController::index
 * @see app/Http/Controllers/Api/V1/EmergencyContactController.php:17
 * @route '/api/v1/emergency-contacts'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\EmergencyContactController::index
 * @see app/Http/Controllers/Api/V1/EmergencyContactController.php:17
 * @route '/api/v1/emergency-contacts'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const EmergencyContactController = { index }

export default EmergencyContactController