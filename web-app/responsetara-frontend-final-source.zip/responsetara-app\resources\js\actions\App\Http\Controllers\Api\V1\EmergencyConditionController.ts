import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\EmergencyConditionController::index
 * @see app/Http/Controllers/Api/V1/EmergencyConditionController.php:17
 * @route '/api/v1/conditions'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/conditions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\EmergencyConditionController::index
 * @see app/Http/Controllers/Api/V1/EmergencyConditionController.php:17
 * @route '/api/v1/conditions'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\EmergencyConditionController::index
 * @see app/Http/Controllers/Api/V1/EmergencyConditionController.php:17
 * @route '/api/v1/conditions'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\EmergencyConditionController::index
 * @see app/Http/Controllers/Api/V1/EmergencyConditionController.php:17
 * @route '/api/v1/conditions'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\EmergencyConditionController::index
 * @see app/Http/Controllers/Api/V1/EmergencyConditionController.php:17
 * @route '/api/v1/conditions'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\EmergencyConditionController::index
 * @see app/Http/Controllers/Api/V1/EmergencyConditionController.php:17
 * @route '/api/v1/conditions'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\EmergencyConditionController::index
 * @see app/Http/Controllers/Api/V1/EmergencyConditionController.php:17
 * @route '/api/v1/conditions'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const EmergencyConditionController = { index }

export default EmergencyConditionController