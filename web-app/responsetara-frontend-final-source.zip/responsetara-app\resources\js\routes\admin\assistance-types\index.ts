import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::restore
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:90
 * @route '/admin/assistance-types/{id}/restore'
 */
export const restore = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

restore.definition = {
    methods: ["post"],
    url: '/admin/assistance-types/{id}/restore',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::restore
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:90
 * @route '/admin/assistance-types/{id}/restore'
 */
restore.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return restore.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::restore
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:90
 * @route '/admin/assistance-types/{id}/restore'
 */
restore.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restore.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::restore
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:90
 * @route '/admin/assistance-types/{id}/restore'
 */
    const restoreForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::restore
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:90
 * @route '/admin/assistance-types/{id}/restore'
 */
        restoreForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, options),
            method: 'post',
        })
    
    restore.form = restoreForm
/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::index
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:19
 * @route '/admin/assistance-types'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/assistance-types',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::index
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:19
 * @route '/admin/assistance-types'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::index
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:19
 * @route '/admin/assistance-types'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::index
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:19
 * @route '/admin/assistance-types'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::index
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:19
 * @route '/admin/assistance-types'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::index
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:19
 * @route '/admin/assistance-types'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::index
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:19
 * @route '/admin/assistance-types'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::store
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:45
 * @route '/admin/assistance-types'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/assistance-types',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::store
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:45
 * @route '/admin/assistance-types'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::store
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:45
 * @route '/admin/assistance-types'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::store
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:45
 * @route '/admin/assistance-types'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::store
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:45
 * @route '/admin/assistance-types'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::update
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:60
 * @route '/admin/assistance-types/{assistance_type}'
 */
export const update = (args: { assistance_type: number | { id: number } } | [assistance_type: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/assistance-types/{assistance_type}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::update
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:60
 * @route '/admin/assistance-types/{assistance_type}'
 */
update.url = (args: { assistance_type: number | { id: number } } | [assistance_type: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assistance_type: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { assistance_type: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    assistance_type: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        assistance_type: typeof args.assistance_type === 'object'
                ? args.assistance_type.id
                : args.assistance_type,
                }

    return update.definition.url
            .replace('{assistance_type}', parsedArgs.assistance_type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::update
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:60
 * @route '/admin/assistance-types/{assistance_type}'
 */
update.put = (args: { assistance_type: number | { id: number } } | [assistance_type: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::update
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:60
 * @route '/admin/assistance-types/{assistance_type}'
 */
update.patch = (args: { assistance_type: number | { id: number } } | [assistance_type: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::update
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:60
 * @route '/admin/assistance-types/{assistance_type}'
 */
    const updateForm = (args: { assistance_type: number | { id: number } } | [assistance_type: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::update
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:60
 * @route '/admin/assistance-types/{assistance_type}'
 */
        updateForm.put = (args: { assistance_type: number | { id: number } } | [assistance_type: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::update
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:60
 * @route '/admin/assistance-types/{assistance_type}'
 */
        updateForm.patch = (args: { assistance_type: number | { id: number } } | [assistance_type: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::destroy
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:75
 * @route '/admin/assistance-types/{assistance_type}'
 */
export const destroy = (args: { assistance_type: number | { id: number } } | [assistance_type: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/assistance-types/{assistance_type}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::destroy
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:75
 * @route '/admin/assistance-types/{assistance_type}'
 */
destroy.url = (args: { assistance_type: number | { id: number } } | [assistance_type: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assistance_type: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { assistance_type: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    assistance_type: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        assistance_type: typeof args.assistance_type === 'object'
                ? args.assistance_type.id
                : args.assistance_type,
                }

    return destroy.definition.url
            .replace('{assistance_type}', parsedArgs.assistance_type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::destroy
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:75
 * @route '/admin/assistance-types/{assistance_type}'
 */
destroy.delete = (args: { assistance_type: number | { id: number } } | [assistance_type: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::destroy
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:75
 * @route '/admin/assistance-types/{assistance_type}'
 */
    const destroyForm = (args: { assistance_type: number | { id: number } } | [assistance_type: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AssistanceTypeController::destroy
 * @see app/Http/Controllers/Admin/AssistanceTypeController.php:75
 * @route '/admin/assistance-types/{assistance_type}'
 */
        destroyForm.delete = (args: { assistance_type: number | { id: number } } | [assistance_type: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const assistanceTypes = {
    restore: Object.assign(restore, restore),
index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default assistanceTypes