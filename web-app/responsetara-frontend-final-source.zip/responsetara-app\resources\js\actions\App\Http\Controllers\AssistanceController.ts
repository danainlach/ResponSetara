import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/bantuan-darurat'
 */
const indexd193afa51042ddd6630dc264cd1b1498 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexd193afa51042ddd6630dc264cd1b1498.url(options),
    method: 'get',
})

indexd193afa51042ddd6630dc264cd1b1498.definition = {
    methods: ["get","head"],
    url: '/bantuan-darurat',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/bantuan-darurat'
 */
indexd193afa51042ddd6630dc264cd1b1498.url = (options?: RouteQueryOptions) => {
    return indexd193afa51042ddd6630dc264cd1b1498.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/bantuan-darurat'
 */
indexd193afa51042ddd6630dc264cd1b1498.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexd193afa51042ddd6630dc264cd1b1498.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/bantuan-darurat'
 */
indexd193afa51042ddd6630dc264cd1b1498.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexd193afa51042ddd6630dc264cd1b1498.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/bantuan-darurat'
 */
    const indexd193afa51042ddd6630dc264cd1b1498Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: indexd193afa51042ddd6630dc264cd1b1498.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/bantuan-darurat'
 */
        indexd193afa51042ddd6630dc264cd1b1498Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: indexd193afa51042ddd6630dc264cd1b1498.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/bantuan-darurat'
 */
        indexd193afa51042ddd6630dc264cd1b1498Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: indexd193afa51042ddd6630dc264cd1b1498.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    indexd193afa51042ddd6630dc264cd1b1498.form = indexd193afa51042ddd6630dc264cd1b1498Form
    /**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/assistance'
 */
const index56bd4572d152c8acc8e88259aad16bca = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index56bd4572d152c8acc8e88259aad16bca.url(options),
    method: 'get',
})

index56bd4572d152c8acc8e88259aad16bca.definition = {
    methods: ["get","head"],
    url: '/assistance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/assistance'
 */
index56bd4572d152c8acc8e88259aad16bca.url = (options?: RouteQueryOptions) => {
    return index56bd4572d152c8acc8e88259aad16bca.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/assistance'
 */
index56bd4572d152c8acc8e88259aad16bca.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index56bd4572d152c8acc8e88259aad16bca.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/assistance'
 */
index56bd4572d152c8acc8e88259aad16bca.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index56bd4572d152c8acc8e88259aad16bca.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/assistance'
 */
    const index56bd4572d152c8acc8e88259aad16bcaForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index56bd4572d152c8acc8e88259aad16bca.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/assistance'
 */
        index56bd4572d152c8acc8e88259aad16bcaForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index56bd4572d152c8acc8e88259aad16bca.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AssistanceController::index
 * @see app/Http/Controllers/AssistanceController.php:24
 * @route '/assistance'
 */
        index56bd4572d152c8acc8e88259aad16bcaForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index56bd4572d152c8acc8e88259aad16bca.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index56bd4572d152c8acc8e88259aad16bca.form = index56bd4572d152c8acc8e88259aad16bcaForm

/**
* Multiple routes resolve to \App\Http\Controllers\AssistanceController::index, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `index['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const index = {
    '/bantuan-darurat': indexd193afa51042ddd6630dc264cd1b1498,
    '/assistance': index56bd4572d152c8acc8e88259aad16bca,
}

const AssistanceController = { index }

export default AssistanceController