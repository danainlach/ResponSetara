import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\DeafController::index
 * @see app/Http/Controllers/DeafController.php:22
 * @route '/tidak-dapat-mendengar'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/tidak-dapat-mendengar',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DeafController::index
 * @see app/Http/Controllers/DeafController.php:22
 * @route '/tidak-dapat-mendengar'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DeafController::index
 * @see app/Http/Controllers/DeafController.php:22
 * @route '/tidak-dapat-mendengar'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DeafController::index
 * @see app/Http/Controllers/DeafController.php:22
 * @route '/tidak-dapat-mendengar'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DeafController::index
 * @see app/Http/Controllers/DeafController.php:22
 * @route '/tidak-dapat-mendengar'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DeafController::index
 * @see app/Http/Controllers/DeafController.php:22
 * @route '/tidak-dapat-mendengar'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DeafController::index
 * @see app/Http/Controllers/DeafController.php:22
 * @route '/tidak-dapat-mendengar'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
 * @see routes/web.php:27
 * @route '/deaf'
 */
export const alias = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: alias.url(options),
    method: 'get',
})

alias.definition = {
    methods: ["get","head"],
    url: '/deaf',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:27
 * @route '/deaf'
 */
alias.url = (options?: RouteQueryOptions) => {
    return alias.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:27
 * @route '/deaf'
 */
alias.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: alias.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:27
 * @route '/deaf'
 */
alias.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: alias.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:27
 * @route '/deaf'
 */
    const aliasForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: alias.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:27
 * @route '/deaf'
 */
        aliasForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: alias.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:27
 * @route '/deaf'
 */
        aliasForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: alias.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    alias.form = aliasForm
const deaf = {
    index: Object.assign(index, index),
alias: Object.assign(alias, alias),
}

export default deaf