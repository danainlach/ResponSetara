import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\StatisticController::index
 * @see app/Http/Controllers/Admin/StatisticController.php:20
 * @route '/admin/statistics'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/statistics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\StatisticController::index
 * @see app/Http/Controllers/Admin/StatisticController.php:20
 * @route '/admin/statistics'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\StatisticController::index
 * @see app/Http/Controllers/Admin/StatisticController.php:20
 * @route '/admin/statistics'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\StatisticController::index
 * @see app/Http/Controllers/Admin/StatisticController.php:20
 * @route '/admin/statistics'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\StatisticController::index
 * @see app/Http/Controllers/Admin/StatisticController.php:20
 * @route '/admin/statistics'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\StatisticController::index
 * @see app/Http/Controllers/Admin/StatisticController.php:20
 * @route '/admin/statistics'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\StatisticController::index
 * @see app/Http/Controllers/Admin/StatisticController.php:20
 * @route '/admin/statistics'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const statistics = {
    index: Object.assign(index, index),
}

export default statistics