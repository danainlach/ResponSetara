import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import categories08bc8d from './categories'
/**
* @see \App\Http\Controllers\Api\V1\SiteConfigController::config
 * @see app/Http/Controllers/Api/V1/SiteConfigController.php:16
 * @route '/api/v1/config'
 */
export const config = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: config.url(options),
    method: 'get',
})

config.definition = {
    methods: ["get","head"],
    url: '/api/v1/config',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\SiteConfigController::config
 * @see app/Http/Controllers/Api/V1/SiteConfigController.php:16
 * @route '/api/v1/config'
 */
config.url = (options?: RouteQueryOptions) => {
    return config.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\SiteConfigController::config
 * @see app/Http/Controllers/Api/V1/SiteConfigController.php:16
 * @route '/api/v1/config'
 */
config.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: config.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\SiteConfigController::config
 * @see app/Http/Controllers/Api/V1/SiteConfigController.php:16
 * @route '/api/v1/config'
 */
config.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: config.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\SiteConfigController::config
 * @see app/Http/Controllers/Api/V1/SiteConfigController.php:16
 * @route '/api/v1/config'
 */
    const configForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: config.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\SiteConfigController::config
 * @see app/Http/Controllers/Api/V1/SiteConfigController.php:16
 * @route '/api/v1/config'
 */
        configForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: config.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\SiteConfigController::config
 * @see app/Http/Controllers/Api/V1/SiteConfigController.php:16
 * @route '/api/v1/config'
 */
        configForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: config.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    config.form = configForm
/**
* @see \App\Http\Controllers\Api\V1\EmergencyCategoryController::categories
 * @see app/Http/Controllers/Api/V1/EmergencyCategoryController.php:16
 * @route '/api/v1/categories'
 */
export const categories = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categories.url(options),
    method: 'get',
})

categories.definition = {
    methods: ["get","head"],
    url: '/api/v1/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\EmergencyCategoryController::categories
 * @see app/Http/Controllers/Api/V1/EmergencyCategoryController.php:16
 * @route '/api/v1/categories'
 */
categories.url = (options?: RouteQueryOptions) => {
    return categories.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\EmergencyCategoryController::categories
 * @see app/Http/Controllers/Api/V1/EmergencyCategoryController.php:16
 * @route '/api/v1/categories'
 */
categories.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categories.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\EmergencyCategoryController::categories
 * @see app/Http/Controllers/Api/V1/EmergencyCategoryController.php:16
 * @route '/api/v1/categories'
 */
categories.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: categories.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\EmergencyCategoryController::categories
 * @see app/Http/Controllers/Api/V1/EmergencyCategoryController.php:16
 * @route '/api/v1/categories'
 */
    const categoriesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: categories.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\EmergencyCategoryController::categories
 * @see app/Http/Controllers/Api/V1/EmergencyCategoryController.php:16
 * @route '/api/v1/categories'
 */
        categoriesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: categories.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\EmergencyCategoryController::categories
 * @see app/Http/Controllers/Api/V1/EmergencyCategoryController.php:16
 * @route '/api/v1/categories'
 */
        categoriesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: categories.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    categories.form = categoriesForm
/**
* @see \App\Http\Controllers\Api\V1\EmergencyConditionController::conditions
 * @see app/Http/Controllers/Api/V1/EmergencyConditionController.php:17
 * @route '/api/v1/conditions'
 */
export const conditions = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: conditions.url(options),
    method: 'get',
})

conditions.definition = {
    methods: ["get","head"],
    url: '/api/v1/conditions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\EmergencyConditionController::conditions
 * @see app/Http/Controllers/Api/V1/EmergencyConditionController.php:17
 * @route '/api/v1/conditions'
 */
conditions.url = (options?: RouteQueryOptions) => {
    return conditions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\EmergencyConditionController::conditions
 * @see app/Http/Controllers/Api/V1/EmergencyConditionController.php:17
 * @route '/api/v1/conditions'
 */
conditions.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: conditions.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\EmergencyConditionController::conditions
 * @see app/Http/Controllers/Api/V1/EmergencyConditionController.php:17
 * @route '/api/v1/conditions'
 */
conditions.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: conditions.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\EmergencyConditionController::conditions
 * @see app/Http/Controllers/Api/V1/EmergencyConditionController.php:17
 * @route '/api/v1/conditions'
 */
    const conditionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: conditions.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\EmergencyConditionController::conditions
 * @see app/Http/Controllers/Api/V1/EmergencyConditionController.php:17
 * @route '/api/v1/conditions'
 */
        conditionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: conditions.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\EmergencyConditionController::conditions
 * @see app/Http/Controllers/Api/V1/EmergencyConditionController.php:17
 * @route '/api/v1/conditions'
 */
        conditionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: conditions.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    conditions.form = conditionsForm
/**
* @see \App\Http\Controllers\Api\V1\AssistanceTypeController::assistanceTypes
 * @see app/Http/Controllers/Api/V1/AssistanceTypeController.php:17
 * @route '/api/v1/assistance-types'
 */
export const assistanceTypes = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: assistanceTypes.url(options),
    method: 'get',
})

assistanceTypes.definition = {
    methods: ["get","head"],
    url: '/api/v1/assistance-types',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\AssistanceTypeController::assistanceTypes
 * @see app/Http/Controllers/Api/V1/AssistanceTypeController.php:17
 * @route '/api/v1/assistance-types'
 */
assistanceTypes.url = (options?: RouteQueryOptions) => {
    return assistanceTypes.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AssistanceTypeController::assistanceTypes
 * @see app/Http/Controllers/Api/V1/AssistanceTypeController.php:17
 * @route '/api/v1/assistance-types'
 */
assistanceTypes.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: assistanceTypes.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\AssistanceTypeController::assistanceTypes
 * @see app/Http/Controllers/Api/V1/AssistanceTypeController.php:17
 * @route '/api/v1/assistance-types'
 */
assistanceTypes.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: assistanceTypes.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\AssistanceTypeController::assistanceTypes
 * @see app/Http/Controllers/Api/V1/AssistanceTypeController.php:17
 * @route '/api/v1/assistance-types'
 */
    const assistanceTypesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: assistanceTypes.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AssistanceTypeController::assistanceTypes
 * @see app/Http/Controllers/Api/V1/AssistanceTypeController.php:17
 * @route '/api/v1/assistance-types'
 */
        assistanceTypesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: assistanceTypes.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\AssistanceTypeController::assistanceTypes
 * @see app/Http/Controllers/Api/V1/AssistanceTypeController.php:17
 * @route '/api/v1/assistance-types'
 */
        assistanceTypesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: assistanceTypes.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    assistanceTypes.form = assistanceTypesForm
/**
* @see \App\Http\Controllers\Api\V1\QuickPhraseController::quickPhrases
 * @see app/Http/Controllers/Api/V1/QuickPhraseController.php:17
 * @route '/api/v1/quick-phrases'
 */
export const quickPhrases = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quickPhrases.url(options),
    method: 'get',
})

quickPhrases.definition = {
    methods: ["get","head"],
    url: '/api/v1/quick-phrases',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\QuickPhraseController::quickPhrases
 * @see app/Http/Controllers/Api/V1/QuickPhraseController.php:17
 * @route '/api/v1/quick-phrases'
 */
quickPhrases.url = (options?: RouteQueryOptions) => {
    return quickPhrases.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\QuickPhraseController::quickPhrases
 * @see app/Http/Controllers/Api/V1/QuickPhraseController.php:17
 * @route '/api/v1/quick-phrases'
 */
quickPhrases.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quickPhrases.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\QuickPhraseController::quickPhrases
 * @see app/Http/Controllers/Api/V1/QuickPhraseController.php:17
 * @route '/api/v1/quick-phrases'
 */
quickPhrases.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: quickPhrases.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\QuickPhraseController::quickPhrases
 * @see app/Http/Controllers/Api/V1/QuickPhraseController.php:17
 * @route '/api/v1/quick-phrases'
 */
    const quickPhrasesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: quickPhrases.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\QuickPhraseController::quickPhrases
 * @see app/Http/Controllers/Api/V1/QuickPhraseController.php:17
 * @route '/api/v1/quick-phrases'
 */
        quickPhrasesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: quickPhrases.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\QuickPhraseController::quickPhrases
 * @see app/Http/Controllers/Api/V1/QuickPhraseController.php:17
 * @route '/api/v1/quick-phrases'
 */
        quickPhrasesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: quickPhrases.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    quickPhrases.form = quickPhrasesForm
/**
* @see \App\Http\Controllers\Api\V1\HelperGuideController::helperGuides
 * @see app/Http/Controllers/Api/V1/HelperGuideController.php:17
 * @route '/api/v1/helper-guides'
 */
export const helperGuides = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: helperGuides.url(options),
    method: 'get',
})

helperGuides.definition = {
    methods: ["get","head"],
    url: '/api/v1/helper-guides',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\HelperGuideController::helperGuides
 * @see app/Http/Controllers/Api/V1/HelperGuideController.php:17
 * @route '/api/v1/helper-guides'
 */
helperGuides.url = (options?: RouteQueryOptions) => {
    return helperGuides.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\HelperGuideController::helperGuides
 * @see app/Http/Controllers/Api/V1/HelperGuideController.php:17
 * @route '/api/v1/helper-guides'
 */
helperGuides.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: helperGuides.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\HelperGuideController::helperGuides
 * @see app/Http/Controllers/Api/V1/HelperGuideController.php:17
 * @route '/api/v1/helper-guides'
 */
helperGuides.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: helperGuides.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\HelperGuideController::helperGuides
 * @see app/Http/Controllers/Api/V1/HelperGuideController.php:17
 * @route '/api/v1/helper-guides'
 */
    const helperGuidesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: helperGuides.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\HelperGuideController::helperGuides
 * @see app/Http/Controllers/Api/V1/HelperGuideController.php:17
 * @route '/api/v1/helper-guides'
 */
        helperGuidesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: helperGuides.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\HelperGuideController::helperGuides
 * @see app/Http/Controllers/Api/V1/HelperGuideController.php:17
 * @route '/api/v1/helper-guides'
 */
        helperGuidesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: helperGuides.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    helperGuides.form = helperGuidesForm
/**
* @see \App\Http\Controllers\Api\V1\EmergencyContactController::emergencyContacts
 * @see app/Http/Controllers/Api/V1/EmergencyContactController.php:17
 * @route '/api/v1/emergency-contacts'
 */
export const emergencyContacts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: emergencyContacts.url(options),
    method: 'get',
})

emergencyContacts.definition = {
    methods: ["get","head"],
    url: '/api/v1/emergency-contacts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\EmergencyContactController::emergencyContacts
 * @see app/Http/Controllers/Api/V1/EmergencyContactController.php:17
 * @route '/api/v1/emergency-contacts'
 */
emergencyContacts.url = (options?: RouteQueryOptions) => {
    return emergencyContacts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\EmergencyContactController::emergencyContacts
 * @see app/Http/Controllers/Api/V1/EmergencyContactController.php:17
 * @route '/api/v1/emergency-contacts'
 */
emergencyContacts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: emergencyContacts.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\EmergencyContactController::emergencyContacts
 * @see app/Http/Controllers/Api/V1/EmergencyContactController.php:17
 * @route '/api/v1/emergency-contacts'
 */
emergencyContacts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: emergencyContacts.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\EmergencyContactController::emergencyContacts
 * @see app/Http/Controllers/Api/V1/EmergencyContactController.php:17
 * @route '/api/v1/emergency-contacts'
 */
    const emergencyContactsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: emergencyContacts.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\EmergencyContactController::emergencyContacts
 * @see app/Http/Controllers/Api/V1/EmergencyContactController.php:17
 * @route '/api/v1/emergency-contacts'
 */
        emergencyContactsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: emergencyContacts.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\EmergencyContactController::emergencyContacts
 * @see app/Http/Controllers/Api/V1/EmergencyContactController.php:17
 * @route '/api/v1/emergency-contacts'
 */
        emergencyContactsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: emergencyContacts.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    emergencyContacts.form = emergencyContactsForm
/**
* @see \App\Http\Controllers\Api\V1\ComposeEmergencyMessageController::__invoke
 * @see app/Http/Controllers/Api/V1/ComposeEmergencyMessageController.php:19
 * @route '/api/v1/compose-message'
 */
export const composeMessage = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: composeMessage.url(options),
    method: 'post',
})

composeMessage.definition = {
    methods: ["post"],
    url: '/api/v1/compose-message',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\ComposeEmergencyMessageController::__invoke
 * @see app/Http/Controllers/Api/V1/ComposeEmergencyMessageController.php:19
 * @route '/api/v1/compose-message'
 */
composeMessage.url = (options?: RouteQueryOptions) => {
    return composeMessage.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\ComposeEmergencyMessageController::__invoke
 * @see app/Http/Controllers/Api/V1/ComposeEmergencyMessageController.php:19
 * @route '/api/v1/compose-message'
 */
composeMessage.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: composeMessage.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\ComposeEmergencyMessageController::__invoke
 * @see app/Http/Controllers/Api/V1/ComposeEmergencyMessageController.php:19
 * @route '/api/v1/compose-message'
 */
    const composeMessageForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: composeMessage.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\ComposeEmergencyMessageController::__invoke
 * @see app/Http/Controllers/Api/V1/ComposeEmergencyMessageController.php:19
 * @route '/api/v1/compose-message'
 */
        composeMessageForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: composeMessage.url(options),
            method: 'post',
        })
    
    composeMessage.form = composeMessageForm
const v1 = {
    config: Object.assign(config, config),
categories: Object.assign(categories, categories08bc8d),
conditions: Object.assign(conditions, conditions),
assistanceTypes: Object.assign(assistanceTypes, assistanceTypes),
quickPhrases: Object.assign(quickPhrases, quickPhrases),
helperGuides: Object.assign(helperGuides, helperGuides),
emergencyContacts: Object.assign(emergencyContacts, emergencyContacts),
composeMessage: Object.assign(composeMessage, composeMessage),
}

export default v1